package com.tactfactory.algotojava.moodle.tp13;

import com.tactfactory.algotojava.moodle.tp13.manager.Bataille;

public class TP13 {

  public static void main(String[] args) {

    Bataille bataille = new Bataille();
    bataille.combatre();
  }

}
