package com.tactfactory.algotojava.moodle.tp13.model;

public enum ArmureType {
  GiletBleu,
  ArmureDeCuir,
  ArmureDePlaque
}
