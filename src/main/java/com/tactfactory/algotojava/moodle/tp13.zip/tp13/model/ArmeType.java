package com.tactfactory.algotojava.moodle.tp13.model;

public enum ArmeType {
  Concasseur,
  Pelle,
  Gatling,
  BatteDeCricket,
  Blaster
}
