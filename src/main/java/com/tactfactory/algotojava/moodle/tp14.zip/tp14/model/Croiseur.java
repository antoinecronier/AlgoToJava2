package com.tactfactory.algotojava.moodle.tp14.model;

public class Croiseur extends Navire {

  public Croiseur(){
    this.setIdentifiant(3);
    this.setTaille(4);
  }
}
