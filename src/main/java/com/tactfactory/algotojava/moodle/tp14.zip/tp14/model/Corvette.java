package com.tactfactory.algotojava.moodle.tp14.model;

public class Corvette extends Navire {

  public Corvette(){
    super();
    this.setIdentifiant(1);
    this.setTaille(1);
  }
}
