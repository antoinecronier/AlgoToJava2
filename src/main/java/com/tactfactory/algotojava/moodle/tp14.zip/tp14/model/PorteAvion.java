package com.tactfactory.algotojava.moodle.tp14.model;

public class PorteAvion extends Navire {

  public PorteAvion(){
    this.setIdentifiant(4);
    this.setTaille(6);
  }
}
