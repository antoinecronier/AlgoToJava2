package com.tactfactory.algotojava.moodle.tp14.model;

public class Destroyer extends Navire {

  public Destroyer(){
    this.setIdentifiant(2);
    this.setTaille(3);
  }
}
